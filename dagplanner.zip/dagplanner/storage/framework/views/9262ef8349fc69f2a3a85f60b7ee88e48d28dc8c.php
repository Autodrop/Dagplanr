<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        
        <style>
        
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }

            
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
         </div>
         




         <style type="text/css">
         #boxA, #boxB, #boxC, #boxD { -moz-user-select:none; }
         #boxA { color: white;background-color: green;width:50px; height:50px; }
         #boxB { color: white;background-color: red;width:50px; height:50px; }
         #boxC { color: white;background-color: blue;width:50px; height:50px; }
         #boxD { background-color: #3a3a3a; width:50px; height:50px; }
        </style>

<script type="text/javascript">
function dragStart(ev) {
   ev.dataTransfer.effectAllowed='move';
   ev.dataTransfer.setData("Text", ev.target.getAttribute('id'));
   ev.dataTransfer.setDragImage(ev.target,0,0);
   return true;
}
function dragEnter(ev) {
   event.preventDefault();
   return true;
}
function dragOver(ev) {
    return false;
}
function dragDrop(ev) {
   var src = ev.dataTransfer.getData("Text");
   ev.target.appendChild(document.getElementById(src));
   ev.stopPropagation();
   return false;
}
 </script>
 
                <TABLE width="200", height="50"> 
                
                <TR>
                <TD id="boxA" draggable="true" ondragstart="return dragStart(event)"> <p>Taak 1</p>
                </TD>
               
                <TD id="boxB" draggable="true" ondragstart="return dragStart(event)"> <p>Taak 2</p>
                <TD id="boxC" draggable="true" ondragstart="return dragStart(event)"> <p>Taak 3</p>
                </TD>
                </TD></TR>
                </TABLE >
            <TABLE width="600", border="2">
            
      <TH COLSPAN="6">
         <H3>Week planning</H3>
      </TH>
   
                <TR align="center">
                <TD></TD>
                    <TD  width="100">Maandag</TD>
                    <TD width="100">Dinsdag</TD>
                    <TD width="100">Woensdag</TD>
                    <TD width="100">Donderdag</TD>
                    <TD width="100">Vrijdag</TD>
                </TR>
                <TR>
                    <TD>Ochtend</TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    
                </TR>
                <TR>
                    <TD>Middag</TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    

                </TR>
                <TR>
                    <TD>Avond</TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    
                </TR>

            </TABLE>

            </div>

            
        </div>
    </body>
</html>
<?php /**PATH /Users/dennisoffinga/code/Dagplanner/resources/views/agenda.blade.php ENDPATH**/ ?>