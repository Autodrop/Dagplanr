<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
        <script src="https://code.jquery.com/ui/1.11.3/jquery-ui.min.js"></script>
        <script>
            $('.date').datepicker({
                autoclose: true,
                dateFormat: "yy-mm-dd"
            });
        </script>
    <title>Document</title>

</head>
<body>
<form action="<?php echo e(route('tasks.store')); ?>" method="post">
  <?php echo e(csrf_field()); ?>

  Task name:
  <br />
  <input type="text" name="name" />
  <br /><br />
  Task description:
  <br />
  <textarea name="description"></textarea>
  <br /><br />
  Start time:
  <br />
  <input type="text" name="task_date" class="date" />
  <br /><br />
  <input type="submit" value="Save" />
</form>
</body>
</html><?php /**PATH /Users/dennisoffinga/code/Dagplanner/resources/views/tasks/create.blade.php ENDPATH**/ ?>