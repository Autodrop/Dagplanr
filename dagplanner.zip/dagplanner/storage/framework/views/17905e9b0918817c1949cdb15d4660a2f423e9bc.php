<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
        
        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <!-- Styles -->
        
        <style>
        
            html, body {
                background-color: #fff;
                background-image: url('https://media.giphy.com/media/uFmH8za4E6M5STIiTu/giphy.gif');
                
                background-size:cover;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
                background-color:#F5F5F5;
               
            }

            h3 {
                color:white;
            }
            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
            #inputtaak{
                color: #fff;
                font-size: 12px;
                background-color: transparent;
                border: none;
                text-align:center;
                
                            }

                            ::placeholder {
                                    color: #fff;
                                    
                            }
            
            #boxA, #boxB, #boxC {

                width:100; 
                height:40px;
                display:flex;
                margin: 5px;
                
                
            }
            
            #boxA{
                background-color: green;
            }
            #boxB{
                background-color: red;
            }
            #boxC{
                background-color: blue;  
            }
            #boxD{
                background-color:#ECECEC;
                width:200px; 
                height:150px;
                border:0.5px solid #828282;
                border-radius:5px;
                


            }
            #boxE{   
                width:100%; 
                height:250px; 
                display:flex;
                flex-direction:column;
                margin:0;
            }
            #done{
                margin-left:10px; 
                width:150px; 
                height:250px;
                
                
            }
            #dagen{
                text-align:center;
                font-weight:800;
                font-size:25px;
            }
            #taken{
                margin-right:10px; 
                width:150px; 
                height:250px;
            }
            
            #buttontaak{
                background-color:transparent;
                border: none;
                color: #fff;
                
            }
            #buttontaak:hover{
                color: #66ff00;
            }       

            #planning{
                border-style:solid;
                border-radius:5px;
                border-color:#dfdfdf;
                width:1000px;
                background-color:white;
                padding:10px;
            } 

            #newtask{  
                width:160px; 
                height:40px;
                
            }
            
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            
<script type="text/javascript">
function dragStart(ev) {
   ev.dataTransfer.effectAllowed='move';
   ev.dataTransfer.setData("Text", ev.target.getAttribute('id'));
   ev.dataTransfer.setDragImage(ev.target,0,0);
   return true;
}
function dragEnter(ev) {
   event.preventDefault();
   return true;
}
function dragOver(ev) {
    return false;
}
function dragDrop(ev) {
   var src = ev.dataTransfer.getData("Text");
   ev.target.appendChild(document.getElementById(src));
   ev.stopPropagation();
   return false;
}

function klaarBoxA(){
     /*  document.getElementById("boxA").style.backgroundColor = "orange"; */
 
    boxE.appendChild(boxA);
   
   }

   function klaarBoxB(){
     /*  document.getElementById("boxA").style.backgroundColor = "orange"; */
 
    boxE.appendChild(boxB);
   }

   function klaarBoxC(){
       /*  document.getElementById("boxA").style.backgroundColor = "orange"; */
 
    boxE.appendChild(boxC);
   }
   function NieuweTaak() {
  document.getElementById("newtask").innerHTML = "Hello test123";
}

$('#newtask').on("click", function(){
  this.parentElement.add();                
});
</script>

         <TABLE id="taken"> 
                
                <TH><H3> Taken</H3>
            <button id="newtask" onclick="NieuweTaak()" class="fa fa-plus" ></button>
            </TH>
             <TR>


                <TD id="boxA" draggable="true" ondragstart="return dragStart(event)"> <input id="inputtaak"  type="text" placeholder='Taak hier invullen'>
                <button id="buttontaak" onclick="klaarBoxA()" class="fa fa-check" ></button>  </TD>

                <TD id="boxB" draggable="true" ondragstart="return dragStart(event)"> <input id="inputtaak"  type='text' placeholder='Taak hier invullen'> 
                <button id="buttontaak" onclick="klaarBoxB()" class="fa fa-check" ></button>  </TD>
                
                <TD id="boxC" draggable="true" ondragstart="return dragStart(event)"> <input id="inputtaak"  type='text' placeholder='Taak hier invullen'> 
                <button id="buttontaak" onclick="klaarBoxC()" class="fa fa-check" ></button>  </TD>   
             </TR>
            
        </TABLE>
        
         <TABLE id="planning">



     
      <TH COLSPAN="6">
         <H3>DAGPLANR</H3>
      </TH>
   
                <TR id="dagen">
                <TD></TD>
                    
                    <TD>MA</TD>
                    <TD>DI</TD>
                    <TD>WO</TD>
                    <TD>DO</TD>
                    <TD>VR</TD>
                   
                </TR>
                <TR>
                    <TD>Ochtend</TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    
                </TR>
                <TR>
                    <TD>Middag</TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    

                </TR>
                <TR>
                    <TD>Avond</TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    <TD id="boxD" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    
                </TR>

            </TABLE>

            <TABLE id="done">
                
                <TH><H3>Afgeronde taken</H3></TH>
                    <TR>
                    <TD id="boxE" ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)"></TD>
                    </TR>
                    
                
            </TABLE>

            </div>

            
        </div>
    </body>
</html>
<?php /**PATH D:\Documenten\Dagplanr web\dagplanner\resources\views/pages/agenda.blade.php ENDPATH**/ ?>